<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class hospital extends Model
{
    protected $table = "tbhospital";
    protected $primaryKey = "id";
}
