<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="jquery-3.4.0.min.js"></script>
  <script src="jquery-ui.js"></script>
  <script src="bootstrap.min.js"></script>
	<link rel="stylesheet" href="bootstrap.min.css" type="text/css">
	<style type="text/css">
		*{
			padding:0px;
			margin:0px;
		}
		#ww1{
			width:100%;
			height:680px;
			background-color:white;
		}
		.wk1{
			position:relative;
			top:150px;
			left:130px;
		}
		.wk2{
			font-size:70px;
			font-family:sans-serif;
			font-weight:thick;
			padding-top:80px;
			padding-left:100px;
		}
		.wk3{
			width:500px;
			height:50px;
			border-radius:10px;
			border:0.5px solid grey;
			position:relative;
			left:30px;
			top:10px;
		}
		.wk4{
			width:500px;
			height:50px;
			border-radius:10px;
			border:0.5px solid grey;
			position:relative;
			left:30px;
			top:30px;
		}
		.wk5{
				width:500px;
			height:50px;
			border-radius:10px;
			border:0.5px solid grey;
			position:relative;
			left:30px;
			top:50px;
		}
		.wk6{
				width:500px;
			height:50px;
			border-radius:10px;
			border:0.5px solid grey;
			position:relative;
			left:30px;
			top:70px;
		}
		.wk7{
			background-color:rgb(67,133,255);
			width:500px;
			height:50px;
			border-radius:10px;
			border:0.2px solid white;
			position:relative;
			top:100px;
			left:30px;
			color:white;
			font-weight:thick;
			font-family:sans-serif;
			font-size:20px;
		}
		.wk8{
			color:rgb(141,141,141);
			font-size:20px;
			position:relative;
			top:100px;
			left:125px;
		}
		.wk9{
			color:rgb(156,156,156);
			font-size:20px;
			top:70px;
			position:relative;
			font-style:italic;
			font-weight:bold;
			left:330px;
		}
	</style>
</head>
<body>
	<div class="container-fluid">
		<div class="row" id="ww1">
			<div class="col-sm-6">
				<img class="wk1" src="cinta2.png">
			</div>
			<div class="col-sm-6">
				<div class="wk2">REGISTER</div>
				<div class=""><input type="text" name="email" placeholder="    email" class="wk3"></div>
				<div class=""><input type="password" name="password" placeholder="    password" class="wk4"></div>
				<div class=""><input type="text" name="name" placeholder="    name" class="wk5"></div>
				<div class=""><input type="text" name="date" placeholder="    date" class="wk6"></div>
				<button class="wk7">REGISTER</button>
				<div class="wk8">Already have account?</div>
				<div class="wk9">Sign in</div>

			</div>
		</div>
	</div>
</body>
</html>