<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="jquery-3.4.0.min.js"></script>
  <script src="jquery-ui.js"></script>
  <script src="bootstrap.min.js"></script>
	<link rel="stylesheet" href="bootstrap.min.css" type="text/css">
	<style type="text/css">
		*{
			padding:0px;
			margin:0px;
		}
		#ww1{
			width:100%;
			height:680px;
			background-color:white;
		}
		.wk1{
			position:relative;
			top:150px;
			left:130px;
		}
		.wk2{
			font-size:70px;
			font-family:sans-serif;
			font-weight:thick;
			padding-top:100px;
			padding-left:130px;
		}
		.wk3{
			width:440px;
			height:50px;
			border-radius:10px;
			border:0.5px solid grey;
			position:relative;
			left:30px;
			top:20px;
		}
		.wk4{
			width:440px;
			height:50px;
			border-radius:10px;
			border:0.5px solid grey;
			position:relative;
			top:40px;
			left:30px;
		}
		.wk5{
			background-color:rgb(67,133,255);
			width:440px;
			height:50px;
			border-radius:10px;
			border:0.2px solid white;
			position:relative;
			top:60px;
			left:30px;
			color:white;
			font-weight:thick;
			font-family:sans-serif;
			font-size:20px;
			letter-spacing:0.5px
		}
		.wk6{
			color:rgb(141,141,141);
			font-size:20px;
			position:relative;
			top:70px;
			left:70px;
		}
		.wk7{
			color:rgb(156,156,156);
			font-size:20px;
			top:40px;
			position:relative;
			font-style:italic;
			font-weight:bold;
			left:330px;
		}
	</style>
</head>
<body>
	<div class="container-fluid">
		<div class="row" id="ww1">
			<div class="col-sm-6">
				<img class="wk1" src="cinta.png">
			</div>
			<div class="col-sm-6">
				<div class="wk2">LOGIN</div>
				<div class=""><input type="text" name="email" placeholder="    email" class="wk3"></div>
				<div class=""><input type="password" name="password" placeholder="    password" class="wk4"></div>
				<button class="wk5">LOGIN</button>
				<div class="wk6">you not ready have account?</div>
				<div class="wk7">Register</div>

			</div>
		</div>
	</div>

</body>
</html>