<?php $__env->startSection('konten'); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>	
	<style type="text/css">
		.bar1{
			padding-right: 10px;
		}
	</style>
</head>
<body>
	<div style="margin-bottom: -154px;margin-top: 180px;">
		<center>
			<img src="../../img/tick.png" style="width: 100px;">
			<div style="font-size: 20px;color: grey;margin-top: 20px;">You have successfully queued in sequence number 123</div>
			<div style="font-size: 21px;margin-top: 10px;">Please arrive at the hospital before 5 P.M</div>
			<button class="btn btn-primary" style="padding: 4px 55px;margin-top: 12px;">BACK</button>
		</center>
	</div>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\github\medics\resources\views/successQueue.blade.php ENDPATH**/ ?>