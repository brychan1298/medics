<?php $__env->startSection('konten'); ?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>	
	<title></title>
	<style type="text/css">
		.bar1{
			padding-right: 10px;
		}	
	    .disables {
	        pointer-events: none;
	        cursor: default;
	        opacity: 40%;
	    }
	</style>
</head>
<body data-spy="scroll" data-target="menu">
	<!-- judul -->
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<center> <div style="margin-bottom: 20px;font-size: 50px;margin-top: 160px;">CEK PAYMENT </div></center>
			</div>
		</div>
	</div>
	<div class="row">				
				<div class="col-sm-12">
					<center>
					<span >
						<input type="text" name="" placeholder="Search" style="border:1px solid grey;border-radius: 15px 0px 0px 15px; padding-right: 550px; padding-top: 10px;padding-bottom: 9px;padding-left: 10px;">
					</span>
					<span style="background-color: #6672EC;padding: 12px;border-radius: 0px 15px 15px 0px; margin-left: -5px;">
						<img src="gambar/searchicon.png" style="width: 30px;">
					</span>
				</center>
				</div>
			</div>
	<!-- form -->
	<div class="container" style="margin-top: 30px;border-radius: 30px; height: 300px">
		<div class="row" style="margin-top:0px;">
			<!-- <div class="col-sm-12">
				<center> <div style="margin-bottom: 40px;font-size: 50px;margin-top: 40px;">	NEW DOCTORS </div></center>
			</div> -->
			<div class="col-sm-12" style="border:1px solid grey;">									
				<table  class="table col-lg-12" style="border-bottom: 1px solid #707070;margin: 5px;">
					<tr style="border-bottom: 1px solid grey;text-align: center;">
						<th style="padding-top: 40px;padding-bottom: 20px;">Name</th>
						<th style="padding-top: 40px;padding-bottom: 20px;">Date</th>						
						<th style="padding-top: 40px;padding-bottom: 20px;">Total</th>						
						<th style="padding-top: 40px;padding-bottom: 20px;">Proof</th>						
						<th  style="padding-top: 40px;padding-bottom: 20px;text-align: center;">Check</th>				
					</tr>
					<?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr style="border-bottom: 1px solid grey;text-align: center;">
						<td style="padding-top: 40px;padding-bottom: 20px;"><?php echo e($aa->tbuser->name); ?></td>
						<td style="padding-top: 40px;padding-bottom: 20px;"><?php echo e($aa->tanggal); ?></td>
						<td style="padding-top: 40px;padding-bottom: 20px;">Rp <?php echo e($aa->total); ?>,00</td>
						<td style="padding-top: 20px;padding-bottom: 20px;"><img src="../../img/<?php echo e($aa->img); ?>" style="width: 60px;" type="button" data-toggle="modal" data-target="#myModal">
							<div class="modal fade" id="myModal">
					    		<div class="modal-dialog">					    					      
					      			<div class="modal-content">
					      				<div class="modal-header">					      		
					      					<h1 style="padding-left:160px;padding-top: 10px;">DETAIL</h1>
								          <button type="button" class="close" data-dismiss="modal">&times;</button>
								        </div>
					        			<div class="modal-body" style="text-align: center;">
					          				<p><img src="../../img/<?php echo e($aa->img); ?>"></p>
					        			</div>
					      			</div>					      
					    		</div>
					  		</div>
						</td>
							<td style="padding-top:40px;padding-bottom: 20px;">
								<center>
									<?php if($aa->status=="BELUM PROSES"): ?>
										<a href="/cekproses/update/<?php echo e($aa->id_transaksi); ?>" value="<?php echo e($aa->id_transaksi); ?>" style="background-color: #4385FF; color: white;border:0px;border-radius: 20px;padding: 10px 30px;margin-right : 10px;">PROSES
										</a>
										<a href="/" class="disables" style="background-color: #4385FF; color: white;border:0px;border-radius: 20px;padding: 10px 30px;">CANCEL
										</a>
									<?php else: ?>
										<a href="/cekproses/update/<?php echo e($aa->id_transaksi); ?>" class="disables" value="<?php echo e($aa->id_transaksi); ?>" style="background-color: #4385FF; color: white;border:0px;border-radius: 20px;padding: 10px 30px;margin-right: 10px;">PROSES
										</a>										
										<a href="/batal/<?php echo e($aa->id_transaksi); ?>" style="background-color: #4385FF; color: white;border:0px;border-radius: 20px;padding: 10px 30px;">CANCEL
										</a>
									<?php endif; ?>
									
								</center>
							</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</table>
			</div>
		</div>
	</div>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\github\medics\resources\views/admin/checkpayment.blade.php ENDPATH**/ ?>