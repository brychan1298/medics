<?php $__env->startSection('konten'); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>	
	<style type="text/css">
		.bar1{
			padding-right: 10px;
		}
	</style>
</head>
<body>
	<div style="font-size: 40px;margin-top: 170px;margin-bottom: 50px;">
		<center>BUY HISTORY</center>
	</div>

	<div class="container" style="margin-bottom: -100px;">
		<?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>		
			<div class="row border mt-4 pt-4 pb-3 pl-3" style="border-radius: 15px;">
				<div class="col-sm-9">
					<div><b><?php echo e($h->tanggal); ?></b></div>
					<div><?php echo e($h->tbtransaksidetil->tbproduk->nama); ?> x<?php echo e($h->tbtransaksidetil->jumlah); ?></div>
					<div>Total : Rp<?php echo e($h->total); ?>,00</div>
					<p></p>
					<p>Destination Account : <?php echo e($h->destinationAcc); ?></p>
				</div>
				<div class="col-sm-3">
					<div class="ml-5 mt-3">
						<?php if($h->status=="BELUM PROSES" && $h->img==""): ?>
						<p class="text-warning">Status : NOT PAID YET</p>
						<p><a href="/proof/<?php echo e($h->id_transaksi); ?>" class="btn btn-primary pl-4 pr-4 mr-5" style="float: right;">CHECK</a></p>	
						<?php else: ?>
						<p class="text-success">Status : PAID</p>						
						<?php endif; ?>
					</div>				
				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\github\medics\resources\views/buyHis.blade.php ENDPATH**/ ?>