<?php $__env->startSection('konten'); ?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>	
	<title></title>
	<style type="text/css">
		.bar1{
			padding-right: 10px;
		}
	</style>
</head>
<body data-spy="scroll" data-target="menu">
	<!-- judul -->
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<center> <div style="margin-bottom: 20px;font-size: 50px;margin-top: 160px;">CUSTOMER</div></center>
			</div>
		</div>
	</div>

	<!-- form -->
	<div class="container" style="margin-top: 30px; margin-bottom: 100px;border-radius: 30px; height: 300px">
		<div class="row" style="margin-top:0px;border: 1px solid">
			<!-- <div class="col-sm-12">
				<center> <div style="margin-bottom: 40px;font-size: 50px;margin-top: 40px;">	NEW DOCTORS </div></center>
			</div> -->
			<div class="col-sm-12">									
				<table class="table col-lg-12" style="border-bottom: 0px solid #707070;margin: 5px;">
					<tr style="border-bottom: 1px solid lightgrey">
						<td colspan="2" style="padding-left: 40px;font-size: 22px;font-weight: bold; font-family: Trebuchet MS; padding-top: 20px;padding-bottom: 20px;"><?php echo e($acustomer->tbuser->name); ?></td>
						<td colspan="3" style="text-align: right;padding-top: 20px;padding-bottom: 20px; font-family: Trebuchet MS;font-size: 20px;font-weight: thin;"><span id="dates" style="padding-right: 30px;text-align: right;"><?php echo e($acustomer->tanggal); ?></span></td>
					</tr>
					<?php $__currentLoopData = $acustomers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr style="padding: 0px;">
						<td style="padding-top: 20px;padding-left: 10px;padding-bottom: 20px;"><img src="../../gambar/<?php echo e($ac->tbproduk->img); ?>" style="width: 80px;"></td>	
						<td class=""><?php echo e($ac->tbproduk->nama); ?></td>
						<td class="">Rp.<?php echo e($ac->tbproduk->harga); ?>,00</td>
						<td class=""><?php echo e($ac->jumlah); ?> Item</td>
						<td class="" style="text-align: right;padding-right: 30px;">Rp.<?php echo e(($ac->jumlah)*($ac->tbproduk->harga)); ?>,00</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<tr style="font-size: 22px;">
						<td colspan="5" style="text-align: right;padding-right: 30px;font-size: 18px;font-weight: semibold;padding-top: 20px;border-top: 1px solid lightgrey;">Subtotal : Rp.<?php echo e($acustomer->total); ?>,00</td>
					</tr>
				</table>
			</div>
		</div>
	</div>
</body>
</html>
<script>
$(document).ready(function () {
  $('.dates').datetimepicker({
    format: 'MMMM/DD/YYYY',
    locale: 'Id'
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\github\medics\resources\views/admin/detailcustomer.blade.php ENDPATH**/ ?>