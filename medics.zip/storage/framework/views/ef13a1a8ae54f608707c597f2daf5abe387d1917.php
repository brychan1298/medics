<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>		
	<title></title>
	<style type="text/css">
		.bar1{
			padding-right: 10px;
		}

		@keyframes
	</style>
</head>
<body data-spy="scroll" data-target="menu">
	<nav style="background-color: rgb(67,133,255);" class="navbar navbar-dark navbar-expand-md fixed-top">
		<h1><img src="img/apasi.png" style="width: 120px;"></h1>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#menu">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="menu">
			<ul class="navbar-nav ml-auto">
				<li class="nav-item bar1">
					<a href="#" class="nav-link text-white">Home</a>					
				</li>
				<li class="nav-item bar1">
					<a href="#" class="nav-link text-white">About Us</a>					
				</li>
				<li class="nav-item bar1">
					<a href="#" class="nav-link text-white">Shop</a>					
				</li>
				<li class="nav-item bar1">
					<a href="#" class="nav-link text-white">Doctors</a>					
				</li>
				<li class="nav-item bar1">
					<a href="#" class="nav-link text-white">Hospital</a>					
				</li>
				<li class="nav-item bar1">
					<a href="#" class="nav-link text-white">Login</a>					
				</li>
				<li class="nav-item bar1">
					<a href="#" class="nav-link text-white"><img src="img/ADDT.png" style="width: 30px;"></a>					
				</li>
			</ul>
		</div>
	</nav>
	<div>
		<img src="img/lolsssss.jpg" style="width: 100%;">
	</div>

	<div style="margin-top: 100px;font-size: 35px;">
		<center>SHOP</center>
	</div>

	<div>
		<img src="img/calendar.png" style="width: 40px;margin-left: 80%;margin-bottom: 100px;">
	</div>

	<div class="container mb-5">	
		<div class="row">			
			<div class="col-sm-12">
				<center>
					<input type="text" name="" style="border:1px solid grey;border-radius: 20px;width: 75%;padding: 10px;" placeholder="Search">
				</center>
			</div>
		</div>
	</div>

	<div class="container">
		<div class="row">
			<div class="col-sm-4 col-6">
				<div style="border:1px solid;border-radius: 25px 25px 0px 0px;">
					<img src="img/obat1.png">
				</div>
				<div style="color: white;background-color: blue;border-radius: 0px 0px 25px 25px; padding:15px;">
					<center>ADD TO CART</center>
				</div>
			</div>
			
			<div class="col-sm-4 col-6">
				<div style="border:1px solid;border-radius: 25px 25px 0px 0px;">
					<img src="img/obat6.png">
				</div>
				<div style="color: white;background-color: blue;border-radius: 0px 0px 25px 25px; padding:15px;">
					<center>ADD TO CART</center>
				</div>
			</div>

			<div class="col-sm-4 col-6" style="margin-bottom: 50px;">
				<div style="border:1px solid;border-radius: 25px 25px 0px 0px;">
					<img src="img/obat5.png">
				</div>
				<div style="color: white;background-color: blue;border-radius: 0px 0px 25px 25px; padding:15px;">
					<center>ADD TO CART</center>
				</div>
			</div>


			<div class="col-sm-4 col-6">
				<div style="border:1px solid;border-radius: 25px 25px 0px 0px;">
					<img src="img/obat1.png">
				</div>
				<div style="color: white;background-color: blue;border-radius: 0px 0px 25px 25px; padding:15px;">
					<center>ADD TO CART</center>
				</div>
			</div>
			
			<div class="col-sm-4 d-none d-lg-block">
				<div style="border:1px solid;border-radius: 25px 25px 0px 0px;">
					<img src="img/obat6.png">
				</div>
				<div style="color: white;background-color: blue;border-radius: 0px 0px 25px 25px; padding:15px;">
					<center>ADD TO CART</center>
				</div>
			</div>

			<div class="col-sm-4 d-none d-lg-block" style="margin-bottom: 50px;">
				<div style="border:1px solid;border-radius: 25px 25px 0px 0px;">
					<img src="img/obat5.png">
				</div>
				<div style="color: white;background-color: blue;border-radius: 0px 0px 25px 25px; padding:15px;">
					<center>ADD TO CART</center>
				</div>
			</div>


			<div class="col-sm-4 d-none d-lg-block">
				<div style="border:1px solid;border-radius: 25px 25px 0px 0px;">
					<img src="img/obat5.png">
				</div>
				<div style="color: white;background-color: blue;border-radius: 0px 0px 25px 25px; padding:15px;">
					<center>ADD TO CART</center>
				</div>
			</div>
			
			<div class="col-sm-4 d-none d-lg-block" style="margin-bottom: 100px;">
				<div style="border:1px solid;border-radius: 25px 25px 0px 0px;">
					<img src="img/obat1.png">
				</div>
				<div style="color: white;background-color: blue;border-radius: 0px 0px 25px 25px; padding:15px;">
					<center>ADD TO CART</center>
				</div>
			</div>

			<div class="col-sm-4 d-none d-lg-block">
				<div style="border:1px solid;border-radius: 25px 25px 0px 0px;">
					<img src="img/obat6.png">
				</div>
				<div style="color: white;background-color: blue;border-radius: 0px 0px 25px 25px; padding:15px;">
					<center>ADD TO CART</center>
				</div>
			</div>

		</div>
	</div>

	<div class="container">		
	<div class="row mt-5 mb-5">
				<div class="col-sm-12">
					<center>
							<div>
								<span>								
									<button  style="border:none;border-radius: 50%;padding: 5px 7px;transform: rotate(180deg);">
										<img src="gambar/hemhem.png" style="width: 20px;">
									</button>
								</span>								
								<span>
									<button  style="background-color:rgb(67,133,255);border:none;border-radius: 50%;padding: 5px 12px;">
										1
									</button>
								</span>
								<span>
									<button  style="border:none;border-radius: 50%;padding: 5px 12px;">
										2
									</button>
								</span>
								<span>
									<button  style="border:none;border-radius: 50%;padding: 5px 12px;">
										3
									</button>
								</span>
								<span>
									<button  style="border:none;border-radius: 50%;padding: 5px 7px;">
										<img src="gambar/hemhem.png" style="width: 20px;">
									</button>
								</span>	
							</div>					
					</center>					
				</div>
			</div>
			</div>

	<div class="row mt-5 d-none d-lg-block" id="ww7" style="background-color: rgb(67,133,255); padding-top: 20px;padding-bottom: 20px;">
		<div class="container">
			<div class="row">
				<div class="col-sm-4">
					<img class="nn1" src="img/asuransi.jpg" style="width: 100px;margin-left: 150px;">
				</div>
				<div class="col-sm-2">
					<div class="jj1">Extra Links</div>
					<div class="jj2">About Us</div>
					<div class="jj3">Doctors</div>
					<div class="jj4">Shop</div>
				</div>
				<div class="col-sm-2">
					<div class="jj5">Contact us</div>
					<div class="jj6">(628)-502-111</div>
					<div class="jj7">brychan@gmail.com</div>
				</div>
				<div class="col-sm-4">
					<div class="jj8">Social Media</div>
					
				</div>
			</div>
		</div>				
	</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\TAmedics\resources\views/shop.blade.php ENDPATH**/ ?>